Software : JetBrains PhpStorm 2018
Framework : Laravel 5.2